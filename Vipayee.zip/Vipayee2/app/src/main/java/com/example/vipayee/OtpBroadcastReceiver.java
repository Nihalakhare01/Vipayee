package com.example.vipayee;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class OtpBroadcastReceiver extends BroadcastReceiver{

    private OTPListener otpListener;

    public void setOtpListener(OTPListener otpListener) {
        this.otpListener = otpListener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                Status status = (Status) extras.get(SmsRetriever.EXTRA_STATUS);
                if (status != null) {
                    switch (status.getStatusCode()) {
                        case CommonStatusCodes.SUCCESS:
                            String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);
                            if (message != null) {
                                String otp = extractOtp(message);
                                if (otpListener != null) {
                                    otpListener.onOtpReceived(otp);
                                }
                            }
                            break;

                        case CommonStatusCodes.TIMEOUT:
                            Toast.makeText(context, "OTP retrieval timed out", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }
        }
    }

    private String extractOtp(String message) {
        Pattern pattern = Pattern.compile("\\d{4,6}");
        Matcher matcher = pattern.matcher(message);
        return matcher.find() ? matcher.group(0) : "";
    }

    public interface OTPListener {
        void onOtpReceived(String otp);
    }
}
