package com.example.vipayee;

public class OTPReceiver {
}
