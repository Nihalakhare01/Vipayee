package com.example.vipayee;

//import androidx.activity.result.ActivityResultLauncher;
//import androidx.activity.result.contract.ActivityResultContracts;
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.annotation.SuppressLint;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.os.Bundle;
//import android.widget.Toast;
//
//import com.google.android.gms.auth.api.phone.SmsRetriever;
//import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
//import com.google.android.material.textfield.TextInputEditText;
//
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class RegisterationOTPActivity extends AppCompatActivity {
//    SmsBroadcastReceiver smsBroadcastReceiver;
//    TextInputEditText etOTP;
//
//    private ActivityResultLauncher<Intent> smsConsentLauncher;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_register_otp);
//
//        etOTP = findViewById(R.id.etOTP);
//
//        // Initialize the ActivityResultLauncher for handling SMS retrieval
//        smsConsentLauncher = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                result -> {
//                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
//                        String message = result.getData().getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
//                        if (message != null) {
//                            String otp = extractOtp(message);
//                            etOTP.setText(otp);
//                            Toast.makeText(this, "OTP Retrieved: " + otp, Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                }
//        );
//
//        startSmartUserConsent();
//    }
//
//    private void startSmartUserConsent() {
//        SmsRetrieverClient client = SmsRetriever.getClient(this);
//        client.startSmsUserConsent(null);
//    }
//
//    @SuppressLint("UnspecifiedRegisterReceiverFlag")
//    private void registerBroadcastReceiver() {
//        smsBroadcastReceiver = new SmsBroadcastReceiver();
//        smsBroadcastReceiver.smsBroadcastReceiverListener = new SmsBroadcastReceiver.SmsBroadcastReceiverListener() {
//            @Override
//            public void onSuccess(Intent intent) {
//                smsConsentLauncher.launch(intent); // Updated from deprecated method
//            }
//
//            @Override
//            public void onFailure() {
//                Toast.makeText(RegisterationOTPActivity.this, "Failed to retrieve OTP", Toast.LENGTH_SHORT).show();
//            }
//        };
//
//        IntentFilter intentFilter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
//        registerReceiver(smsBroadcastReceiver, intentFilter);
//    }
//
//    private String extractOtp(String message) {
//        Pattern otpPattern = Pattern.compile("\\d{4,6}");
//        Matcher matcher = otpPattern.matcher(message);
//        if (matcher.find()) {
//            return matcher.group(0);
//        }
//        return "";
//    }
//
//    @Override
//    protected void onStart() {
//        super.onStart();
//        registerBroadcastReceiver();
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        unregisterReceiver(smsBroadcastReceiver);
//    }
//}



import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;

public class RegisterationOTPActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;
    private OTPReceiver otpReceiver;
    private SharedPreferences preferences;

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_otp);

        preferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Check if permissions have been granted before
        if (!preferences.getBoolean("permissionGranted", false)) {
            // If permissions haven't been granted yet, request them
            requestSmsPermission();
        } else {
            // If permission already granted, start listening for OTP automatically
            startListeningForOtp();
        }

        // Register the receiver to listen for OTP
        otpReceiver = new OTPReceiver();
        IntentFilter filter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
        registerReceiver(otpReceiver, filter);
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // If permission is already granted, start listening for OTP
            startListeningForOtp();
        }
    }

    private void startListeningForOtp() {
        SmsRetrieverClient client = SmsRetriever.getClient(this);
        client.startSmsRetriever()
                .addOnSuccessListener(aVoid -> {
                    // Successfully started listening for OTP
                    Log.d("OTP", "Listening for OTP");
                })
                .addOnFailureListener(e -> {
                    // Failed to start listening for OTP
                    Log.e("OTP", "Error starting SMS Retriever", e);
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the receiver when the activity is destroyed
        unregisterReceiver(otpReceiver);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Save permission granted status in SharedPreferences
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("permissionGranted", true);
                editor.apply();
                startListeningForOtp(); // Start listening for OTP after permission is granted
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}